package com.cdbhe.plana.mvvm.base_activity.model;

public class ButtonModel {
    private String btnText;

    public ButtonModel() {
    }

    public ButtonModel(String btnText) {
        this.btnText = btnText;
    }

    public String getBtnText() {
        return btnText;
    }

    public void setBtnText(String btnText) {
        this.btnText = btnText;
    }
}
