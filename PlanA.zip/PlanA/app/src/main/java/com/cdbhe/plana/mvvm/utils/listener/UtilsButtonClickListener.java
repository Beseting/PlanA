package com.cdbhe.plana.mvvm.utils.listener;

public interface UtilsButtonClickListener {
    void onItemButtonClick(int position);
}
