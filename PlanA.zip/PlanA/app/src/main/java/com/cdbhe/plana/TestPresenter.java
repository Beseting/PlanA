package com.cdbhe.plana;

import android.content.Context;

public class TestPresenter extends RequestCallback {
    public TestPresenter(Context context) {
        super(context);
    }

}
