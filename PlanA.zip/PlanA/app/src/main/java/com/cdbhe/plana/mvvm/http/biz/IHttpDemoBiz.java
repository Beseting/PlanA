package com.cdbhe.plana.mvvm.http.biz;

import com.cdbhe.plib.http.retrofit.IBaseBiz;

public interface IHttpDemoBiz extends IBaseBiz {
    String getSearchContent();
}
