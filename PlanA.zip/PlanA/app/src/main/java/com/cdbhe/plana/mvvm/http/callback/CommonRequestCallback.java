package com.cdbhe.plana.mvvm.http.callback;

import com.cdbhe.plib.http.retrofit.ResCallback;

public class CommonRequestCallback implements ResCallback<String> {

    @Override
    public void onResponse(String s) {

    }

    @Override
    public void onError(Throwable e) {

    }
}
